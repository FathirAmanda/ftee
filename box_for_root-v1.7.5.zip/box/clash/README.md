
########################
example configuration / documentation
########################

~[clash premium documentation](http://dreamacro.github.io/clash/)~

[mihomo documentation](https://wiki.metacubex.one/)